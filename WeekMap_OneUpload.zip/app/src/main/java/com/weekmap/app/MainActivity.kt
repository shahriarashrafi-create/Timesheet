package com.weekmap.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    data class WeekEvent(
        var id: Long,
        var day: Int,
        var startHour: Int,
        var endHour: Int,
        var title: String,
        var recurring: Boolean,
        var status: String = "planned",
        var templateId: Long = 0L
    )

    private val days = arrayOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    private val events = mutableListOf<WeekEvent>()
    private val recurringTemplates = mutableListOf<WeekEvent>()
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var gridView: WeekGridView
    private lateinit var stats: TextView
    private lateinit var weekLabel: TextView
    private lateinit var prevButton: Button
    private lateinit var nextButton: Button
    private lateinit var dayColumnView: DayColumnView

    private val todayWeekStart: LocalDate by lazy { saturdayOf(LocalDate.now()) }
    private var selectedWeekStart: LocalDate = LocalDate.now()
    private var weekOffset = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("weekmap_data", Context.MODE_PRIVATE)
        selectedWeekStart = todayWeekStart
        loadRecurringTemplates()
        migrateLegacyIfNeeded()
        loadWeek(selectedWeekStart)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        val headerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = roundedBg(Color.rgb(252, 252, 251), Color.rgb(229, 231, 235), 14f, 1f)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val brandLogo = ImageView(this).apply {
            setImageResource(R.drawable.billionaires_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Billionaires Team"
            setPadding(dp(2), dp(1), dp(4), dp(1))
        }

        stats = TextView(this).apply {
            textSize = 10f
            setTextColor(Color.rgb(75, 85, 99))
            gravity = Gravity.CENTER
            setPadding(dp(4), 0, dp(4), 0)
            maxLines = 2
        }

        val overview = Button(this).apply {
            text = "نمای کلی"
            textSize = 10f
            isAllCaps = false
            setTextColor(Color.rgb(244, 199, 86))
            background = roundedBg(Color.rgb(17, 24, 39), Color.rgb(244, 199, 86), 12f, 1f)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { showWeekOverview() }
        }

        brandRow.addView(brandLogo, LinearLayout.LayoutParams(dp(76), dp(52)))
        brandRow.addView(stats, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
            marginStart = dp(8)
            marginEnd = dp(8)
        })
        brandRow.addView(overview, LinearLayout.LayoutParams(dp(88), dp(42)))
        headerCard.addView(brandRow)

        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
        }

        prevButton = Button(this).apply {
            text = "‹ هفته قبل"
            textSize = 9f
            isAllCaps = false
            setTextColor(Color.rgb(55, 65, 81))
            background = roundedBg(Color.WHITE, Color.rgb(209, 171, 67), 11f, 1f)
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { changeWeek(-1) }
        }

        weekLabel = TextView(this).apply {
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(31, 41, 55))
            paint.isFakeBoldText = true
            background = roundedBg(Color.rgb(250, 247, 239), Color.rgb(235, 225, 197), 11f, 1f)
            setPadding(dp(6), dp(3), dp(6), dp(3))
            maxLines = 2
        }

        nextButton = Button(this).apply {
            text = "هفته بعد ›"
            textSize = 9f
            isAllCaps = false
            setTextColor(Color.rgb(55, 65, 81))
            background = roundedBg(Color.WHITE, Color.rgb(209, 171, 67), 11f, 1f)
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { changeWeek(1) }
        }

        navRow.addView(prevButton, LinearLayout.LayoutParams(dp(88), dp(40)))
        navRow.addView(weekLabel, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            marginStart = dp(6)
            marginEnd = dp(6)
        })
        navRow.addView(nextButton, LinearLayout.LayoutParams(dp(88), dp(40)))
        headerCard.addView(navRow)

        root.addView(headerCard, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(8)
            marginEnd = dp(8)
            topMargin = dp(4)
            bottomMargin = dp(6)
        })

        gridView = WeekGridView(this, compact = false, showDayColumn = false)
        dayColumnView = DayColumnView(this)
        val stickyFrame = FrameLayout(this)
        val horizontal = HorizontalScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(gridView)
        }
        val timeLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            marginEnd = dp(74)
        }
        stickyFrame.addView(horizontal, timeLp)
        stickyFrame.addView(
            dayColumnView,
            FrameLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END)
        )
        val vertical = ScrollView(this).apply {
            isFillViewport = true
            addView(stickyFrame)
        }
        root.addView(vertical, LinearLayout.LayoutParams(-1, 0, 1f))
        horizontal.post { horizontal.fullScroll(View.FOCUS_RIGHT) }
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
        refreshHeader()
    }

    private fun changeWeek(delta: Int) {
        val target = (weekOffset + delta).coerceIn(-10, 10)
        if (target == weekOffset) {
            Toast.makeText(this, "حداکثر ۱۰ هفته قابل جابه‌جایی است", Toast.LENGTH_SHORT).show()
            return
        }
        saveWeek(selectedWeekStart)
        weekOffset = target
        selectedWeekStart = todayWeekStart.plusWeeks(weekOffset.toLong())
        loadWeek(selectedWeekStart)
        refreshHeader()
        gridView.requestLayout()
        gridView.invalidate()
        dayColumnView.invalidate()
    }

    private fun refreshHeader() {
        updateStats()
        val end = selectedWeekStart.plusDays(6)
        val startJ = jalaliText(selectedWeekStart)
        val endJ = jalaliText(end)
        weekLabel.text = if (weekOffset == 0) "این هفته\n$startJ تا $endJ" else "$startJ تا $endJ"
        prevButton.isEnabled = weekOffset > -10
        nextButton.isEnabled = weekOffset < 10
    }

    private fun updateStats() {
        val plannedHours = events.sumOf { it.endHour - it.startHour }
        val done = events.filter { it.status == "done" }.sumOf { it.endHour - it.startHour }
        val missed = events.filter { it.status == "missed" }.sumOf { it.endHour - it.startHour }
        val free = (7 * 17 - plannedHours).coerceAtLeast(0)
        stats.text = "برنامه $plannedHours  ✓ $done  ✕ $missed  آزاد $free"
    }

    inner class WeekGridView(context: Context, private val compact: Boolean, private val showDayColumn: Boolean = true) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(148, 163, 184)
            style = Paint.Style.STROKE
            strokeWidth = if (compact) dpF(0.55f) else dpF(0.8f)
        }
        private var headerH = if (compact) dpF(28f) else dpF(36f)
        private var rowH = if (compact) dpF(44f) else dpF(82f)
        private val minCellW = if (compact) dpF(14f) else dpF(62f)
        private val normalDayW = if (compact) dpF(56f) else dpF(74f)
        private var dayW = normalDayW
        private var cellW = minCellW

        init {
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            if (compact) {
                val available = MeasureSpec.getSize(widthMeasureSpec).toFloat().coerceAtLeast(dpF(300f))
                dayW = (available * 0.18f).coerceIn(dpF(52f), dpF(72f))
                cellW = ((available - dayW) / 17f).coerceAtLeast(dpF(11f))
                val desiredH = (headerH + 7 * rowH + dpF(2f)).toInt()
                setMeasuredDimension(available.toInt(), desiredH)
            } else {
                dayW = if (showDayColumn) normalDayW else 0f
                val screenW = resources.displayMetrics.widthPixels.toFloat()
                val stickyDayW = if (showDayColumn) dayW else dpF(74f)
                cellW = max(minCellW, (screenW - stickyDayW - dpF(4f)) / 6f)
                val desiredW = (17 * cellW + dayW).toInt()
                val desiredH = (headerH + 7 * rowH + dpF(2f)).toInt()
                setMeasuredDimension(desiredW, desiredH)
            }
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.WHITE)
            val totalW = 17 * cellW + dayW
            val dayLeft = totalW - dayW

            for (slot in 0 until 17) {
                val x = dayLeft - (slot + 1) * cellW
                val r = RectF(x, 0f, x + cellW, headerH)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                canvas.drawRect(r, paint)
                canvas.drawRect(r, borderPaint)
                val label = if (compact) "${slot + 7}" else "${slot + 7}-${slot + 8}"
                drawCentered(canvas, label, r, if (compact) dpF(6.2f) else dpF(10f), Color.DKGRAY)
            }
            if (showDayColumn) {
                val blank = RectF(dayLeft, 0f, totalW, headerH)
                canvas.drawRect(blank, borderPaint)
            }

            for (day in 0 until 7) {
                val top = headerH + day * rowH
                val bottom = top + rowH
                val isToday = selectedWeekStart.plusDays(day.toLong()) == LocalDate.now()
                if (showDayColumn) {
                    val dayRect = RectF(dayLeft, top, totalW, bottom)
                    paint.style = Paint.Style.FILL
                    paint.color = if (isToday) Color.rgb(243, 244, 246) else Color.WHITE
                    canvas.drawRect(dayRect, paint)
                    canvas.drawRect(dayRect, borderPaint)
                    val date = jalaliText(selectedWeekStart.plusDays(day.toLong()), short = true)
                    val label = "${days[day]}\n$date"
                    drawMultilineCentered(canvas, label, dayRect, if (compact) dpF(8f) else dpF(12f), Color.DKGRAY)
                }

                for (slot in 0 until 17) {
                    val hour = slot + 7
                    val x = dayLeft - (slot + 1) * cellW
                    val rect = RectF(x, top, x + cellW, bottom)
                    val ev = findEvent(day, hour)
                    paint.style = Paint.Style.FILL
                    paint.color = when (ev?.status) {
                        "done" -> Color.rgb(220, 252, 231)
                        "missed" -> Color.rgb(254, 226, 226)
                        "planned" -> Color.rgb(248, 250, 252)
                        else -> if (isToday) Color.rgb(246, 247, 249) else Color.WHITE
                    }
                    canvas.drawRect(rect, paint)
                    canvas.drawRect(rect, borderPaint)
                }

                events.filter { it.day == day }.forEach { ev ->
                    val left = dayLeft - (ev.endHour - 7) * cellW
                    val right = dayLeft - (ev.startHour - 7) * cellW
                    val eventRect = RectF(left + dpF(2.5f), top + dpF(4f), right - dpF(2.5f), bottom - dpF(4f))
                    paint.style = Paint.Style.FILL
                    paint.color = when (ev.status) {
                        "done" -> Color.rgb(220, 252, 231)
                        "missed" -> Color.rgb(254, 226, 226)
                        else -> Color.rgb(248, 250, 252)
                    }
                    canvas.drawRoundRect(eventRect, dpF(7f), dpF(7f), paint)
                    drawHatch(canvas, eventRect, ev.status)
                    val symbol = if (ev.recurring) "↻" else "•"
                    val status = when (ev.status) { "done" -> "✓ "; "missed" -> "✕ "; else -> "" }
                    if (!compact || eventRect.width() >= dpF(34f)) {
                        drawWrappedWords(canvas, "$status$symbol ${ev.title}", eventRect, if (compact) dpF(7f) else dpF(10f), Color.rgb(15, 23, 42))
                    }
                }
            }
        }

        private fun drawHatch(canvas: Canvas, rect: RectF, status: String) {
            canvas.save()
            canvas.clipRect(rect)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (compact) dpF(0.8f) else dpF(1.25f)
            paint.color = when (status) {
                "done" -> Color.rgb(74, 160, 105)
                "missed" -> Color.rgb(210, 92, 92)
                else -> Color.rgb(148, 163, 184)
            }
            var x = rect.left - rowH
            while (x < rect.right + rowH) {
                canvas.drawLine(x, rect.bottom, x + rowH, rect.top, paint)
                x += if (compact) dpF(5f) else dpF(7f)
            }
            canvas.restore()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (compact) return false
            if (event.action != MotionEvent.ACTION_UP) return true
            val totalW = 17 * cellW + dayW
            val dayLeft = totalW - dayW
            val x = event.x
            val y = event.y
            if (y < headerH) return true
            val day = ((y - headerH) / rowH).toInt()
            if (day !in 0..6) return true
            if (x >= dayLeft) return true
            val slotFromRight = ((dayLeft - x) / cellW).toInt()
            val slot = slotFromRight.coerceIn(0, 16)
            val hour = 7 + slot
            val existing = findEvent(day, hour)
            if (existing == null) showEventEditor(null, day, hour) else showEventActions(existing)
            return true
        }

        private fun drawCentered(canvas: Canvas, text: String, rect: RectF, size: Float, color: Int) {
            paint.style = Paint.Style.FILL
            paint.color = color
            paint.textSize = size
            paint.textAlign = Paint.Align.CENTER
            val fm = paint.fontMetrics
            val y = rect.centerY() - (fm.ascent + fm.descent) / 2f
            canvas.drawText(text, rect.centerX(), y, paint)
        }

        private fun drawMultilineCentered(canvas: Canvas, text: String, rect: RectF, size: Float, color: Int) {
            val lines = text.split("\n")
            paint.style = Paint.Style.FILL
            paint.color = color
            paint.textSize = size
            paint.textAlign = Paint.Align.CENTER
            val gap = size * 1.35f
            var y = rect.centerY() - ((lines.size - 1) * gap / 2f)
            for (line in lines) {
                val fm = paint.fontMetrics
                canvas.drawText(line, rect.centerX(), y - (fm.ascent + fm.descent) / 2f, paint)
                y += gap
            }
        }

        private fun drawWrappedWords(canvas: Canvas, text: String, rect: RectF, size: Float, color: Int) {
            paint.style = Paint.Style.FILL
            paint.color = color
            paint.textSize = size
            paint.textAlign = Paint.Align.CENTER
            val maxWidth = (rect.width() - dpF(6f)).coerceAtLeast(dpF(14f))
            val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            val lines = mutableListOf<String>()
            var current = ""
            for (word in words) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(candidate) <= maxWidth || current.isEmpty()) current = candidate
                else { lines += current; current = word }
            }
            if (current.isNotEmpty()) lines += current
            val fm = paint.fontMetrics
            val lineH = (fm.descent - fm.ascent) * 1.08f
            val maxLines = ((rect.height() / lineH).toInt()).coerceAtLeast(1)
            val visible = lines.take(maxLines)
            var baseline = rect.centerY() - ((visible.size - 1) * lineH / 2f) - (fm.ascent + fm.descent) / 2f
            for (line in visible) {
                canvas.drawText(line, rect.centerX(), baseline, paint)
                baseline += lineH
            }
        }
    }

    inner class DayColumnView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(148, 163, 184)
            style = Paint.Style.STROKE
            strokeWidth = dpF(0.8f)
        }
        private val headerH = dpF(36f)
        private val rowH = dpF(82f)
        private val dayW = dpF(74f)

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            setMeasuredDimension(dayW.toInt(), (headerH + 7 * rowH + dpF(2f)).toInt())
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(250, 247, 239))
            val header = RectF(0f, 0f, dayW, headerH)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(240, 230, 201)
            canvas.drawRect(header, paint)
            canvas.drawRect(header, border)
            for (day in 0 until 7) {
                val top = headerH + day * rowH
                val rect = RectF(0f, top, dayW, top + rowH)
                val isToday = selectedWeekStart.plusDays(day.toLong()) == LocalDate.now()
                paint.style = Paint.Style.FILL
                paint.color = if (isToday) Color.rgb(229, 231, 235) else Color.rgb(250, 247, 239)
                canvas.drawRect(rect, paint)
                canvas.drawRect(rect, border)
                val date = jalaliText(selectedWeekStart.plusDays(day.toLong()), short = true)
                paint.style = Paint.Style.FILL
                paint.color = Color.rgb(55, 65, 81)
                paint.textSize = dpF(10.5f)
                paint.textAlign = Paint.Align.CENTER
                val lines = listOf(days[day], date)
                val gap = dpF(15f)
                var y = rect.centerY() - gap / 2f
                for ((index, line) in lines.withIndex()) {
                    paint.isFakeBoldText = index == 0
                    paint.color = if (index == 0) Color.rgb(71, 58, 27) else Color.rgb(100, 92, 75)
                    val fm = paint.fontMetrics
                    canvas.drawText(line, rect.centerX(), y - (fm.ascent + fm.descent) / 2f, paint)
                    y += gap
                }
                paint.isFakeBoldText = false
            }
        }
    }

    private fun showWeekOverview() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), 0)
        }
        val caption = TextView(this).apply {
            text = "نمای یک‌جای برنامه هفته • ${jalaliText(selectedWeekStart)} تا ${jalaliText(selectedWeekStart.plusDays(6))}"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(6))
        }
        val overview = WeekGridView(this, compact = true)
        box.addView(caption, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(overview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle("Timesheet")
            .setView(box)
            .setPositiveButton("بستن", null)
            .show()
    }

    private fun findEvent(day: Int, hour: Int): WeekEvent? =
        events.firstOrNull { it.day == day && hour >= it.startHour && hour < it.endHour }

    private fun showEventEditor(existing: WeekEvent?, day: Int, selectedHour: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val title = EditText(this).apply {
            hint = "نام برنامه"
            setText(existing?.title ?: "")
            textDirection = View.TEXT_DIRECTION_RTL
        }
        val start = EditText(this).apply {
            hint = "ساعت شروع"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existing?.startHour ?: selectedHour).toString())
        }
        val end = EditText(this).apply {
            hint = "ساعت پایان"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existing?.endHour ?: selectedHour + 1).toString())
        }
        val recurring = CheckBox(this).apply {
            text = "برنامه ثابت هفتگی ↻"
            isChecked = existing?.recurring ?: true
        }
        box.addView(title); box.addView(start); box.addView(end); box.addView(recurring)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "برنامه جدید - ${days[day]} ${jalaliText(selectedWeekStart.plusDays(day.toLong()), true)}" else "ویرایش برنامه")
            .setView(box)
            .setPositiveButton("ذخیره", null)
            .setNegativeButton("لغو", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = title.text.toString().trim()
                val s = start.text.toString().toIntOrNull()
                val e = end.text.toString().toIntOrNull()
                if (t.isBlank() || s == null || e == null || s !in 7..23 || e !in 8..24 || e <= s) {
                    Toast.makeText(this, "عنوان یا ساعت صحیح نیست", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val overlap = events.any { it.id != existing?.id && it.day == day && s < it.endHour && e > it.startHour }
                if (overlap) {
                    Toast.makeText(this, "این بازه قبلاً پر شده", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (existing == null) {
                    val newId = System.currentTimeMillis()
                    val templateId = if (recurring.isChecked) newId else 0L
                    val newEvent = WeekEvent(newId, day, s, e, t, recurring.isChecked, "planned", templateId)
                    events += newEvent
                    if (recurring.isChecked) {
                        recurringTemplates.removeAll { it.templateId == templateId }
                        recurringTemplates += newEvent.copy(id = templateId, status = "planned")
                        saveRecurringTemplates()
                    }
                } else {
                    val wasRecurring = existing.recurring
                    val oldTemplate = existing.templateId
                    existing.startHour = s; existing.endHour = e; existing.title = t; existing.recurring = recurring.isChecked
                    if (recurring.isChecked) {
                        if (existing.templateId == 0L) existing.templateId = if (oldTemplate != 0L) oldTemplate else existing.id
                        recurringTemplates.removeAll { it.templateId == existing.templateId }
                        recurringTemplates += existing.copy(id = existing.templateId, status = "planned")
                        updateRecurringAcrossStoredWeeks(existing)
                        saveRecurringTemplates()
                    } else if (wasRecurring && oldTemplate != 0L) {
                        recurringTemplates.removeAll { it.templateId == oldTemplate }
                        removeRecurringFromStoredWeeks(oldTemplate, exceptCurrent = true)
                        existing.templateId = 0L
                        saveRecurringTemplates()
                    }
                }
                saveWeek(selectedWeekStart); refreshHeader(); gridView.invalidate(); dayColumnView.invalidate(); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showEventActions(ev: WeekEvent) {
        val options = arrayOf("✅ انجام شد", "❌ انجام نشد", "◻️ برگرداندن به برنامه", "✏️ ویرایش", "🗑 حذف")
        AlertDialog.Builder(this)
            .setTitle(ev.title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> ev.status = "done"
                    1 -> ev.status = "missed"
                    2 -> ev.status = "planned"
                    3 -> { showEventEditor(ev, ev.day, ev.startHour); return@setItems }
                    4 -> {
                        if (ev.recurring && ev.templateId != 0L) {
                            recurringTemplates.removeAll { it.templateId == ev.templateId }
                            removeRecurringFromStoredWeeks(ev.templateId, exceptCurrent = false)
                            saveRecurringTemplates()
                        }
                        events.removeAll { it.id == ev.id }
                    }
                }
                saveWeek(selectedWeekStart); refreshHeader(); gridView.invalidate(); dayColumnView.invalidate()
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun weekKey(start: LocalDate) = "week_events_${start.format(DateTimeFormatter.ISO_LOCAL_DATE)}"

    private fun loadWeek(start: LocalDate) {
        events.clear()
        val raw = prefs.getString(weekKey(start), null)
        if (raw != null) {
            parseEvents(JSONArray(raw), events)
        }
        mergeMissingRecurringTemplates()
        saveWeek(start)
    }

    private fun saveWeek(start: LocalDate) {
        prefs.edit().putString(weekKey(start), eventsToJson(events).toString()).apply()
    }

    private fun mergeMissingRecurringTemplates() {
        recurringTemplates.forEach { template ->
            if (events.none { it.recurring && it.templateId == template.templateId }) {
                events += template.copy(
                    id = System.currentTimeMillis() + template.day + template.startHour,
                    status = "planned"
                )
            }
        }
    }

    private fun updateRecurringAcrossStoredWeeks(updated: WeekEvent) {
        for (offset in -10..10) {
            val start = todayWeekStart.plusWeeks(offset.toLong())
            val key = weekKey(start)
            val raw = prefs.getString(key, null) ?: continue
            val list = mutableListOf<WeekEvent>()
            parseEvents(JSONArray(raw), list)
            var changed = false
            list.filter { it.recurring && it.templateId == updated.templateId }.forEach {
                it.day = updated.day
                it.startHour = updated.startHour
                it.endHour = updated.endHour
                it.title = updated.title
                changed = true
            }
            if (changed) prefs.edit().putString(key, eventsToJson(list).toString()).apply()
        }
    }

    private fun removeRecurringFromStoredWeeks(templateId: Long, exceptCurrent: Boolean) {
        for (offset in -10..10) {
            val start = todayWeekStart.plusWeeks(offset.toLong())
            if (exceptCurrent && start == selectedWeekStart) continue
            val key = weekKey(start)
            val raw = prefs.getString(key, null) ?: continue
            val list = mutableListOf<WeekEvent>()
            parseEvents(JSONArray(raw), list)
            val changed = list.removeAll { it.recurring && it.templateId == templateId }
            if (changed) prefs.edit().putString(key, eventsToJson(list).toString()).apply()
        }
    }

    private fun loadRecurringTemplates() {
        recurringTemplates.clear()
        try {
            val arr = JSONArray(prefs.getString("recurring_templates_v3", "[]") ?: "[]")
            parseEvents(arr, recurringTemplates)
        } catch (_: Exception) { }
    }

    private fun saveRecurringTemplates() {
        prefs.edit().putString("recurring_templates_v3", eventsToJson(recurringTemplates).toString()).apply()
    }

    private fun migrateLegacyIfNeeded() {
        if (prefs.getBoolean("v3_migrated", false)) return
        val legacy = prefs.getString("events", null)
        if (legacy != null && prefs.getString(weekKey(todayWeekStart), null) == null) {
            try {
                val old = mutableListOf<WeekEvent>()
                parseEvents(JSONArray(legacy), old)
                old.forEach {
                    if (it.recurring) {
                        if (it.templateId == 0L) it.templateId = it.id
                        recurringTemplates.removeAll { t -> t.templateId == it.templateId }
                        recurringTemplates += it.copy(status = "planned")
                    }
                }
                prefs.edit().putString(weekKey(todayWeekStart), eventsToJson(old).toString()).apply()
                saveRecurringTemplates()
            } catch (_: Exception) { }
        }
        prefs.edit().putBoolean("v3_migrated", true).apply()
    }

    private fun eventsToJson(list: List<WeekEvent>): JSONArray {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("day", it.day); put("startHour", it.startHour); put("endHour", it.endHour)
                put("title", it.title); put("recurring", it.recurring); put("status", it.status); put("templateId", it.templateId)
            })
        }
        return arr
    }

    private fun parseEvents(arr: JSONArray, target: MutableList<WeekEvent>) {
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val recurring = o.optBoolean("recurring", false)
            val id = o.optLong("id", System.currentTimeMillis() + i)
            target += WeekEvent(
                id = id,
                day = o.optInt("day", 0),
                startHour = o.optInt("startHour", 7),
                endHour = o.optInt("endHour", 8),
                title = o.optString("title", ""),
                recurring = recurring,
                status = o.optString("status", "planned"),
                templateId = o.optLong("templateId", if (recurring) id else 0L)
            )
        }
    }

    private fun saturdayOf(date: LocalDate): LocalDate {
        val daysSinceSaturday = (date.dayOfWeek.value - 6 + 7) % 7
        return date.minusDays(daysSinceSaturday.toLong())
    }

    private fun jalaliText(date: LocalDate, short: Boolean = false): String {
        val (jy, jm, jd) = gregorianToJalali(date.year, date.monthValue, date.dayOfMonth)
        val raw = if (short) String.format("%02d/%02d", jm, jd) else String.format("%04d/%02d/%02d", jy, jm, jd)
        return toPersianDigits(raw)
    }

    private fun gregorianToJalali(gyInput: Int, gmInput: Int, gdInput: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
        var gy = gyInput - 1600
        val gm = gmInput - 1
        val gd = gdInput - 1
        var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
        for (i in 0 until gm) gDayNo += gDaysInMonth[i]
        val leap = (gyInput % 4 == 0 && gyInput % 100 != 0) || (gyInput % 400 == 0)
        if (gm > 1 && leap) gDayNo++
        gDayNo += gd
        var jDayNo = gDayNo - 79
        val jNp = jDayNo / 12053
        jDayNo %= 12053
        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461
        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }
        var jm = 0
        while (jm < 11 && jDayNo >= jDaysInMonth[jm]) {
            jDayNo -= jDaysInMonth[jm]
            jm++
        }
        return Triple(jy, jm + 1, jDayNo + 1)
    }

    private fun toPersianDigits(text: String): String {
        val en = "0123456789"
        val fa = "۰۱۲۳۴۵۶۷۸۹"
        return text.map { c ->
            val i = en.indexOf(c)
            if (i >= 0) fa[i] else c
        }.joinToString("")
    }

    override fun onStop() {
        saveWeek(selectedWeekStart)
        super.onStop()
    }

    private fun roundedBg(fillColor: Int, strokeColor: Int, radiusDp: Float, strokeDp: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fillColor)
            cornerRadius = dpF(radiusDp)
            setStroke(dpF(strokeDp).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpF(v: Float) = v * resources.displayMetrics.density
}
