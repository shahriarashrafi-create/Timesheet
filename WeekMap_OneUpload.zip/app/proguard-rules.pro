# WeekMap ProGuard rules
