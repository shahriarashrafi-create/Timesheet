package com.weekmap.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    data class WeekEvent(
        var id: Long,
        var day: Int,
        var startHour: Int,
        var endHour: Int,
        var title: String,
        var recurring: Boolean,
        var status: String = "planned"
    )

    private val days = arrayOf("شنبه", "یکشنبه", "دوشنبه", "سه شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    private val events = mutableListOf<WeekEvent>()
    private val dates = MutableList(7) { "" }
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var gridView: WeekGridView
    private lateinit var stats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("weekmap_data", Context.MODE_PRIVATE)
        loadData()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        val title = TextView(this).apply {
            text = "WeekMap"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(dp(8), 0, dp(8), 0)
        }
        stats = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        val history = Button(this).apply {
            text = "History"
            textSize = 10f
            setOnClickListener { showHistory() }
        }
        val newWeek = Button(this).apply {
            text = "New Week"
            textSize = 10f
            setOnClickListener { confirmNewWeek() }
        }

        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        bar.addView(stats, LinearLayout.LayoutParams(0, dp(44), 1.2f))
        bar.addView(history, LinearLayout.LayoutParams(dp(90), dp(44)))
        bar.addView(newWeek, LinearLayout.LayoutParams(dp(98), dp(44)))
        root.addView(bar)

        gridView = WeekGridView(this)
        val horizontal = HorizontalScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(gridView)
        }
        val vertical = ScrollView(this).apply {
            isFillViewport = true
            addView(horizontal)
        }
        root.addView(vertical, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        updateStats()
    }

    private fun updateStats() {
        val plannedHours = events.sumOf { it.endHour - it.startHour }
        val done = events.filter { it.status == "done" }.sumOf { it.endHour - it.startHour }
        val missed = events.filter { it.status == "missed" }.sumOf { it.endHour - it.startHour }
        val free = (7 * 17 - plannedHours).coerceAtLeast(0)
        stats.text = "برنامه $plannedHours  ✓ $done  ✕ $missed  آزاد $free"
    }

    inner class WeekGridView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = dpF(1.25f)
        }
        private val headerH = dpF(36f)
        private val rowH = dpF(82f)
        private val minCellW = dpF(62f)
        private val dayW = dpF(92f)
        private var cellW = minCellW

        init {
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val screenW = resources.displayMetrics.widthPixels.toFloat()
            cellW = max(minCellW, (screenW - dayW - dpF(4f)) / 17f)
            val desiredW = (17 * cellW + dayW).toInt()
            val desiredH = (headerH + 7 * rowH + dpF(2f)).toInt()
            setMeasuredDimension(desiredW, desiredH)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.WHITE)
            val totalW = 17 * cellW + dayW
            val dayLeft = totalW - dayW

            // top hour headers: 7-8 at right, 23-24 at left
            for (slot in 0 until 17) {
                val x = dayLeft - (slot + 1) * cellW
                val r = RectF(x, 0f, x + cellW, headerH)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                canvas.drawRect(r, paint)
                canvas.drawRect(r, borderPaint)
                drawCentered(canvas, "${slot + 7}-${slot + 8}", r, dpF(10f), Color.DKGRAY)
            }
            val blank = RectF(dayLeft, 0f, totalW, headerH)
            canvas.drawRect(blank, borderPaint)

            for (day in 0 until 7) {
                val top = headerH + day * rowH
                val bottom = top + rowH

                // day title cell on right
                val dayRect = RectF(dayLeft, top, totalW, bottom)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                canvas.drawRect(dayRect, paint)
                canvas.drawRect(dayRect, borderPaint)
                val label = if (dates[day].isBlank()) days[day] else "${days[day]}\n${dates[day]}"
                drawMultilineCentered(canvas, label, dayRect, dpF(13f), Color.DKGRAY)

                for (slot in 0 until 17) {
                    val hour = slot + 7
                    val x = dayLeft - (slot + 1) * cellW
                    val rect = RectF(x, top, x + cellW, bottom)
                    val ev = findEvent(day, hour)

                    paint.style = Paint.Style.FILL
                    paint.color = when (ev?.status) {
                        "done" -> Color.rgb(220, 252, 231)
                        "missed" -> Color.rgb(254, 226, 226)
                        "planned" -> Color.rgb(248, 250, 252)
                        else -> Color.WHITE
                    }
                    canvas.drawRect(rect, paint)

                    if (ev?.status == "planned") drawHatch(canvas, rect)
                    canvas.drawRect(rect, borderPaint)

                    if (ev != null && ev.startHour == hour) {
                        val symbol = if (ev.recurring) "↻" else "•"
                        val status = when (ev.status) { "done" -> "✓"; "missed" -> "✕"; else -> "" }
                        val txt = "$status$symbol ${ev.title}"
                        drawWrapped(canvas, txt, rect, dpF(10f), Color.rgb(17, 24, 39))
                    }
                }
            }
        }

        private fun drawHatch(canvas: Canvas, rect: RectF) {
            canvas.save()
            canvas.clipRect(rect)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dpF(0.75f)
            paint.color = Color.rgb(203, 213, 225)
            var x = rect.left - rowH
            while (x < rect.right + rowH) {
                canvas.drawLine(x, rect.bottom, x + rowH, rect.top, paint)
                x += dpF(11f)
            }
            canvas.restore()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            val totalW = 17 * cellW + dayW
            val dayLeft = totalW - dayW
            val x = event.x
            val y = event.y
            if (y < headerH) return true
            val day = ((y - headerH) / rowH).toInt()
            if (day !in 0..6) return true

            if (x >= dayLeft) {
                editDate(day)
                return true
            }

            val slotFromRight = ((dayLeft - x) / cellW).toInt()
            val slot = slotFromRight.coerceIn(0, 16)
            val hour = 7 + slot
            val existing = findEvent(day, hour)
            if (existing == null) showEventEditor(null, day, hour) else showEventActions(existing)
            return true
        }

        private fun drawCentered(canvas: Canvas, text: String, rect: RectF, size: Float, color: Int) {
            paint.style = Paint.Style.FILL
            paint.color = color
            paint.textSize = size
            paint.textAlign = Paint.Align.CENTER
            val fm = paint.fontMetrics
            val y = rect.centerY() - (fm.ascent + fm.descent) / 2f
            canvas.drawText(text, rect.centerX(), y, paint)
        }

        private fun drawMultilineCentered(canvas: Canvas, text: String, rect: RectF, size: Float, color: Int) {
            val lines = text.split("\n")
            paint.style = Paint.Style.FILL
            paint.color = color
            paint.textSize = size
            paint.textAlign = Paint.Align.CENTER
            val gap = size * 1.35f
            var y = rect.centerY() - ((lines.size - 1) * gap / 2f)
            for (line in lines) {
                val fm = paint.fontMetrics
                canvas.drawText(line, rect.centerX(), y - (fm.ascent + fm.descent) / 2f, paint)
                y += gap
            }
        }

        private fun drawWrapped(canvas: Canvas, text: String, rect: RectF, size: Float, color: Int) {
            paint.style = Paint.Style.FILL
            paint.color = color
            paint.textSize = size
            paint.textAlign = Paint.Align.CENTER
            val maxChars = max(4, (rect.width() / (size * 0.62f)).toInt())
            val lines = text.chunked(maxChars).take(3)
            val gap = size * 1.2f
            var y = rect.centerY() - ((lines.size - 1) * gap / 2f)
            for (line in lines) {
                val fm = paint.fontMetrics
                canvas.drawText(line, rect.centerX(), y - (fm.ascent + fm.descent) / 2f, paint)
                y += gap
            }
        }
    }

    private fun findEvent(day: Int, hour: Int): WeekEvent? =
        events.firstOrNull { it.day == day && hour >= it.startHour && hour < it.endHour }

    private fun showEventEditor(existing: WeekEvent?, day: Int, selectedHour: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val title = EditText(this).apply {
            hint = "نام برنامه"
            setText(existing?.title ?: "")
            textDirection = View.TEXT_DIRECTION_RTL
        }
        val start = EditText(this).apply {
            hint = "ساعت شروع"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existing?.startHour ?: selectedHour).toString())
        }
        val end = EditText(this).apply {
            hint = "ساعت پایان"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText((existing?.endHour ?: selectedHour + 1).toString())
        }
        val recurring = CheckBox(this).apply {
            text = "برنامه ثابت هفتگی ↻"
            isChecked = existing?.recurring ?: false
        }
        box.addView(title); box.addView(start); box.addView(end); box.addView(recurring)

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "برنامه جدید - ${days[day]}" else "ویرایش برنامه")
            .setView(box)
            .setPositiveButton("ذخیره", null)
            .setNegativeButton("لغو", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = title.text.toString().trim()
                val s = start.text.toString().toIntOrNull()
                val e = end.text.toString().toIntOrNull()
                if (t.isBlank() || s == null || e == null || s !in 7..23 || e !in 8..24 || e <= s) {
                    Toast.makeText(this, "عنوان یا ساعت صحیح نیست", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val overlap = events.any { it.id != existing?.id && it.day == day && s < it.endHour && e > it.startHour }
                if (overlap) {
                    Toast.makeText(this, "این بازه قبلاً پر شده", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (existing == null) {
                    events += WeekEvent(System.currentTimeMillis(), day, s, e, t, recurring.isChecked)
                } else {
                    existing.startHour = s; existing.endHour = e; existing.title = t; existing.recurring = recurring.isChecked
                }
                saveData(); updateStats(); gridView.invalidate(); dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showEventActions(ev: WeekEvent) {
        val options = arrayOf("✅ انجام شد", "❌ انجام نشد", "◻️ برگرداندن به برنامه", "✏️ ویرایش", "🗑 حذف")
        AlertDialog.Builder(this)
            .setTitle(ev.title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> ev.status = "done"
                    1 -> ev.status = "missed"
                    2 -> ev.status = "planned"
                    3 -> { showEventEditor(ev, ev.day, ev.startHour); return@setItems }
                    4 -> { events.removeAll { it.id == ev.id } }
                }
                saveData(); updateStats(); gridView.invalidate()
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun editDate(day: Int) {
        val input = EditText(this).apply {
            hint = "مثلاً ۷ شهریور"
            setText(dates[day])
            textDirection = View.TEXT_DIRECTION_RTL
        }
        AlertDialog.Builder(this)
            .setTitle("تاریخ ${days[day]}")
            .setView(input)
            .setPositiveButton("ذخیره") { _, _ ->
                dates[day] = input.text.toString().trim()
                saveData(); gridView.invalidate()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun confirmNewWeek() {
        AlertDialog.Builder(this)
            .setTitle("هفته جدید")
            .setMessage("هفته فعلی آرشیو شود و برنامه‌های ثابت برای هفته جدید باقی بمانند؟")
            .setPositiveButton("بله") { _, _ -> archiveCurrentWeek(); startNewWeek() }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun archiveCurrentWeek() {
        if (events.isEmpty() && dates.all { it.isBlank() }) return
        val history = JSONArray(prefs.getString("history", "[]") ?: "[]")
        val week = JSONObject()
        week.put("savedAt", System.currentTimeMillis())
        val ds = JSONArray(); dates.forEach { ds.put(it) }; week.put("dates", ds)
        val es = JSONArray()
        events.forEach {
            es.put(JSONObject().apply {
                put("id", it.id); put("day", it.day); put("startHour", it.startHour); put("endHour", it.endHour)
                put("title", it.title); put("recurring", it.recurring); put("status", it.status)
            })
        }
        week.put("events", es); history.put(week)
        val trimmed = JSONArray(); val from = (history.length() - 52).coerceAtLeast(0)
        for (i in from until history.length()) trimmed.put(history.getJSONObject(i))
        prefs.edit().putString("history", trimmed.toString()).apply()
    }

    private fun startNewWeek() {
        val recurring = events.filter { it.recurring }.mapIndexed { index, e ->
            e.copy(id = System.currentTimeMillis() + index, status = "planned")
        }
        events.clear(); events.addAll(recurring)
        for (i in dates.indices) dates[i] = ""
        saveData(); updateStats(); gridView.invalidate()
    }

    private fun showHistory() {
        val history = JSONArray(prefs.getString("history", "[]") ?: "[]")
        if (history.length() == 0) {
            Toast.makeText(this, "هنوز آرشیوی وجود ندارد", Toast.LENGTH_SHORT).show(); return
        }
        val labels = mutableListOf<String>()
        for (i in history.length() - 1 downTo 0) {
            val w = history.getJSONObject(i); val ds = w.getJSONArray("dates"); val es = w.getJSONArray("events")
            val a = ds.optString(0, "").ifBlank { "بدون تاریخ" }; val b = ds.optString(6, "").ifBlank { "بدون تاریخ" }
            labels += "$a تا $b  |  ${es.length()} برنامه"
        }
        AlertDialog.Builder(this).setTitle("History")
            .setItems(labels.toTypedArray()) { _, pos -> showHistoryWeek(history.getJSONObject(history.length() - 1 - pos)) }
            .setNegativeButton("بستن", null).show()
    }

    private fun showHistoryWeek(week: JSONObject) {
        val ds = week.getJSONArray("dates"); val es = week.getJSONArray("events"); val sb = StringBuilder()
        for (day in 0..6) {
            sb.append(days[day]); val d = ds.optString(day, ""); if (d.isNotBlank()) sb.append(" - $d"); sb.append("\n")
            var any = false
            for (i in 0 until es.length()) {
                val e = es.getJSONObject(i); if (e.getInt("day") == day) {
                    any = true
                    val mark = when (e.optString("status")) { "done" -> "✓"; "missed" -> "✕"; else -> "○" }
                    sb.append("$mark ${e.getInt("startHour")}-${e.getInt("endHour")}  ${e.getString("title")}\n")
                }
            }
            if (!any) sb.append("—\n"); sb.append("\n")
        }
        val text = TextView(this).apply { this.text = sb.toString(); textSize = 15f; setPadding(dp(20), dp(12), dp(20), dp(12)); textDirection = View.TEXT_DIRECTION_RTL }
        val scroll = ScrollView(this).apply { addView(text) }
        AlertDialog.Builder(this).setTitle("جزئیات هفته").setView(scroll).setPositiveButton("بستن", null).show()
    }

    private fun saveData() {
        val es = JSONArray()
        events.forEach {
            es.put(JSONObject().apply {
                put("id", it.id); put("day", it.day); put("startHour", it.startHour); put("endHour", it.endHour)
                put("title", it.title); put("recurring", it.recurring); put("status", it.status)
            })
        }
        val ds = JSONArray(); dates.forEach { ds.put(it) }
        prefs.edit().putString("events", es.toString()).putString("dates", ds.toString()).apply()
    }

    private fun loadData() {
        try {
            val es = JSONArray(prefs.getString("events", "[]") ?: "[]")
            for (i in 0 until es.length()) {
                val o = es.getJSONObject(i)
                events += WeekEvent(o.optLong("id", System.currentTimeMillis()), o.optInt("day", 0), o.optInt("startHour", 7), o.optInt("endHour", 8), o.optString("title", ""), o.optBoolean("recurring", false), o.optString("status", "planned"))
            }
            val ds = JSONArray(prefs.getString("dates", "[]") ?: "[]")
            for (i in 0..6) dates[i] = if (i < ds.length()) ds.optString(i, "") else ""
        } catch (_: Exception) { }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpF(v: Float) = v * resources.displayMetrics.density
}
